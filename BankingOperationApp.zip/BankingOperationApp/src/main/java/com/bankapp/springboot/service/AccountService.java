package com.bankapp.springboot.service;

import java.util.List;

import com.bankapp.springboot.dto.AccountDto;
import com.bankapp.springboot.entity.Account;
import com.bankapp.springboot.mapper.AccountMapper;
import com.bankapp.springboot.repository.AccountRepository;

public interface AccountService {
	
	AccountDto createAccount(AccountDto accountDto);
	
	AccountDto getAccountById(Long id);
	
	AccountDto deposit(Long id , double ammount);
	
	AccountDto withdraw(Long id, double ammount);
	
	List<AccountDto> getAllAccounts();
	
	void deleteAccount(Long id);

	

	

}

