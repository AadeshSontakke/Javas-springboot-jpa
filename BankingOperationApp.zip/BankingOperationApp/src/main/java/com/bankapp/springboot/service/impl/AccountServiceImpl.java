package com.bankapp.springboot.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.bankapp.springboot.dto.AccountDto;
import com.bankapp.springboot.entity.Account;
import com.bankapp.springboot.mapper.AccountMapper;
import com.bankapp.springboot.repository.AccountRepository;
import com.bankapp.springboot.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService{

	private AccountRepository accountRepository;
	
	public AccountServiceImpl(AccountRepository accountRepository) {
		super();
		this.accountRepository = accountRepository;
	}

	@Override
	public AccountDto createAccount(AccountDto accountDto) {
		
		Account account = AccountMapper.mapToAccount(accountDto);
		Account savedAccount = accountRepository.save(account);
		return AccountMapper.mapToAccountDto(savedAccount);
	}

	@Override
	public AccountDto getAccountById(Long id) {
		
		Account account =  accountRepository.findById(id).orElseThrow(()-> new RuntimeException("Account Does not Found"));
		
		return AccountMapper.mapToAccountDto(account);
	}

	@Override
	public AccountDto deposit(Long id, double ammount) {
		
		Account account =  accountRepository.findById(id).orElseThrow(()-> new RuntimeException("Account Does not Found"));
		 
		double totalBalance =account.getBalance()+ammount;
		account.setBalance(totalBalance);
		Account savedAccount= accountRepository.save(account);
		
	 
		
		return AccountMapper.mapToAccountDto(savedAccount);
	}

	@Override
	public AccountDto withdraw(Long id, double ammount) {
		
		Account account =  accountRepository.findById(id).orElseThrow(()-> new RuntimeException("Account Does not Found"));
		 
		if(account.getBalance()<ammount)
		{
			throw new RuntimeException("Insufficient Balance");
		}
		double totalBalance =  account.getBalance()-ammount;
		account.setBalance(totalBalance);
		Account savedAccount =  accountRepository.save(account);
		
		
		return AccountMapper.mapToAccountDto(savedAccount);
	}

	@Override
	public List<AccountDto> getAllAccounts() {
		
		return accountRepository.findAll().stream().map((account)->AccountMapper.mapToAccountDto(account)).collect(Collectors.toList());
		
	}

	@Override
	public void deleteAccount(Long id) {
		Account account =  accountRepository.findById(id).orElseThrow(()-> new RuntimeException("Account Does not Found"));
		 accountRepository.delete(account);
		
	}


	


	
	}

	
	

	





