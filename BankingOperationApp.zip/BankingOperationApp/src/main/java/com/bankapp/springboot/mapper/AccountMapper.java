package com.bankapp.springboot.mapper;

import com.bankapp.springboot.dto.AccountDto;
import com.bankapp.springboot.entity.Account;

public class AccountMapper {
	
	public static Account mapToAccount(AccountDto accountDto) //data goes from accountDto to Account
	{
		Account account = new Account(
				accountDto.getId(),
				accountDto.getAccountHolderName(),
				accountDto.getBalance()
				);
		return account;
		
	}
	
	// creating method to transfer data from Account to AccountDto
	
	public static  AccountDto mapToAccountDto(Account account)
	{
		AccountDto accountDto = new AccountDto(
				account.getId(),
				account.getAccountHolderName(),
				account.getBalance()
				);
		
		return accountDto;
		
		
	}


}
